/**
 * 
 */
/**
 * @author student
 *
 */
module spbook {
}