package spbook;

import java.util.*;

public class Book {
		 public String bookName;
		 public List<Author> authorList = new ArrayList<Author>();
		 public List<Element> elementList = new ArrayList<Element>();
		public Book(String bookName) {
			this.bookName = bookName;
		}
		public boolean addAuthor(Author e) {
			return authorList.add(e);
		}
		public int addElement(Element e) {
			elementList.add(e);
			return elementList.indexOf(e);
		}
		public String getName() {
			return this.bookName;
		}
		public void print() {
			System.out.println("Book: " + this.getName());
			for(Author a : authorList) {
				System.out.println("Author: " + a.getName());
			}
			for(Element e : elementList) {
				e.print();
				
			}
		}
		 
}
