package spbook;

public class Table implements Element {
	public String tableName;
	public Table(String name) {
		this.tableName = name;
	}
	public String getName() {
		return this.tableName;
	}
	public void print() {
		System.out.println("Tabel cu titlu: " + this.getName());
	}
}
