package spbook;

public class Author {
	public String authorName;

	public Author(String authorName) {
		this.authorName = authorName;
	}
	public String getName() {
		return this.authorName;
	}
	
}
