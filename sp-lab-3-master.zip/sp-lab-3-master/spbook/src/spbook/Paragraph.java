package spbook;

public class Paragraph implements Element {
	public String paraName;
	public Paragraph(String name) {
		this.paraName = name;
	}
	public String getName() {
		return this.paraName;
	}
	public void print() {
		System.out.println("Paragraful " + this.getName());
	}
}
