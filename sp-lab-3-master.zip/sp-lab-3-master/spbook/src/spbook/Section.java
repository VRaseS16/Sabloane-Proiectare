package spbook;

import java.util.*;

public class Section implements Element {
	public String sectionTitle;
	public List<Element> content = new ArrayList<Element>();
	
	public Section(String sectionName) {
		this.sectionTitle = sectionName;
		
	}
	public String getName() {
		return this.sectionTitle;
	}
	public int add(Element e) {
		content.add(e);
		return content.indexOf(e);
	}
	public void remove(Element e) {
		content.remove(e);
	}
	public Element getElementbyIndex(int index) {
		return content.get(index);
	}
	public void print() {
			System.out.println(sectionTitle);
		for(Element elem : content) {
			elem.print();	
			}
		}
}
