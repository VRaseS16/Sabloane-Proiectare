package spbook;

public class Image implements Element{
	public String imageName;
	public Image(String name) {
		this.imageName = name;
	}
	public String getName() {
		return this.imageName;
	}
	public void print() {
		System.out.println("Imagine cu nume: " + this.getName());
	}
}
