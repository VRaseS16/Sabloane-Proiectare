package spbook;

public abstract interface Element {
	public abstract void print();
}
